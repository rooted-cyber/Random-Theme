printf "\n\n\033[1;93m Type\033[1;96m help\033[1;93m to see all shortcut\n"
printf "\033[1;93m Type\033[1;96m z-menu\033[1;93m to Open zsh menu\n"
printf "\033[1;93m Type\033[1;96m Ta\033[1;93m To use Termux\n\n"
Ta() {
	if [ -e ~/Theme/term ];then
	cd $PREFIX/bin
	./rm -f ~/.zshrc
	./cp ~/Theme/term ~/.zshrc
	fi
	}
	
PROMPT=$'
%{\033[1;91m%} ╭─%{\033[1;91m%}[%{\033[1;96m%}Termux%{\033[0m%}%B@%{\033[93m%}%B%m%{\033[1;91m%}]%{\033[1;91m%}──%{\033[1;91m%}[%{\033[0m%}%{\033[32m%}%~%{\033[1;91m%}]%{\033[1;91m%}%{\033[1;91m%}─[%{\033[1;92m%}%B%T%{\033[1;91m%}]
 %{\033[1;91m%}╰───%{\033[1;96m%}➤ %{\033[6 q%}'
