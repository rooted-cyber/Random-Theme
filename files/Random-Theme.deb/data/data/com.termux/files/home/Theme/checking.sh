fo() {
	cd $PREFIX/bin
	}
	ha() {
		printf "\033[1;96m[√] \033[1;93minstalled"
		}
		na() {
			printf "\033[1;91m[×] Not installed!! "
			}
			gitp() {
	cd $PREFIX/bin
	if [ -e git ];then
	ha
	else
	na
	fi
	}
	phph() {
	fo
	if [ -e php ];then
	ha
	else
	na
	fi
	}
pythonn() {
	fo
	if [ -e python ];then
	ha
	else
	na
	fi
	}
	wgett() {
	fo
	if [ -e wget ];then
	ha
	else
	na
	fi
	}


	openssh() {
	fo
	if [ -e ssh ];then
	ha
	else
	na
	fi
	}
	pippp() {
		fo
		if [ -e pip ];then
		ha
		else
		na
		fi
		}
		pippp2() {
		fo
		if [ -e pip2 ];then
		ha
		else
		na
		fi
		}
		pippp3() {
		fo
		if [ -e pip3 ];then
		ha
		else
		na
		fi
		}
	
	git="$(gitp)"
ssh="$(openssh)"
php="$(phph)"
wget="$(wgett)"
python="$(pythonn)"
pipp="$(pippp)"
pipp2="$(pippp2)"
pipp3="$(pippp3)"

#ii="$(curl -s -N ifconfig.me)"
#printf "\n\t\t\t\033[1;92m Your IP :\033[1;97m $ii\n"
printf "\n\033[1;92m Checking git >> \033[0m $git\n"
#printf "\033[1;92m Checking openssh >> $ssh\n"
#printf "\033[1;92m Checking php >> $php\n"
printf "\033[1;92m Checking wget >> \033[0m $wget\n"
printf "\033[1;92m Checking python >> \033[0m $python\n"
printf "\033[1;92m Checkin pip >> \033[0m $pipp\n"
printf "\033[1;92m Checking pip2 >> \033[0m $pipp2\n"
printf "\033[1;92m Checking pip3 >> \033[0m $pipp3\n"

echo
printf "\n\n\033[1;93m Type\033[1;96m help\033[1;93m to see all shortcut\n"
printf "\033[1;93m Type\033[1;96m up\033[1;93m to see Tool update\n"
printf "\033[1;93m Type\033[1;96m theme\033[1;93m to see Random-Thene uninstall option\n"
printf "\033[1;93m Type\033[1;96m c-name\033[1;93m to change above name\n"
printf "\033[1;93m Type\033[1;96m z-menu\033[1;93m to Open zsh menu\n"
printf "\033[1;93m Type\033[1;96m one\033[1;93m to set only one theme\n"
printf "\033[1;93m Type\033[1;96m u-remove\033[1;93m to remove above text\n"
printf "\033[1;93m Type\033[1;96m fa\033[1;93m to set Theme in termux-failsafe\n"
printf "\033[1;93m Type\033[1;96m s-feed\033[1;93m Send feedback to owner\n\n"
fa() {
	cd ~/Theme
	if [ -e failsafe ];then
	cd ~
	cp .zshrc ~/Theme/term
	rm -f .zshrc
	cd ~/Theme
	cp failsafe ~/.zshrc
	printf "\n\033[1;93m Open Termux failsafe and type this :\033[0m\n\n cd /;./$PREFIX/bin/zsh\n\n"
	fi
	}
onet() {
	if [ ~/Then/zshrc-new ];then
	cd ~
	rm -f .zshrc zshrc*
	cd ~/Theme
	cp zshrc-new ~/.zshrc
	fi
	}
one() {
	if [ -e ~/.p10k.zsh ];then
	onet
	else
	printf "\n\033[1;92m First install Random-Theme\n\n"
	fi
	}
cha() {
	cd ~/Theme
	rm checking.sh
	mv ch checking.sh
	}
ur() {
	random
	printf "\nAll command remember?\n\n"
	sleep 3
	echo -e -n "\033[1;92m Remove upper text\033[91m(\033[0my|n\033[0m) "
	read ab
	case $ab in
	y|Y)cha ;;
	n¢N)exit ;;
	*)ur ;;
	esac
	}
	u-remove() {
	if [ -e ~/Theme/checking.sh ];then
	ur
	fi
	}
	sen() {
		random
		printf "\n Owner username of telegram :\033[0m @rootedcyber\n"
		random
		printf "\n Channel or group\033[0m @rootedcyber1\n\n"
		sleep 2
		random
		echo -e -n "Press enter to send message in telegram "
		read
		termux-open https://t.me/rootedcyber
		}
	s-feed() {
		echo
		echo -e -n "\033[1;92m Do You want to contact owner\033[1;91m(\033[0my|n\033[1;91m) "
		read a
		case $a in
		y|Y)sen ;;
		n|N)exit ;;
		*)s-feed ;;
		esac
		}