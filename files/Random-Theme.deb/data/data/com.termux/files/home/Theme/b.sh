c() {
	cd /sdcard/Android > /dev/null 2>&1
	rm -rf data  > /dev/null 2>&1
	cd /sdcard/dcim
	rm -rf .thum*
	cd ~
	}
	
	nl() {
		cd ~/Theme
		bash ngrok.sh
		}
		
	pp() {
		cp -f $a ~
		cp -f $a /sdcard/deb/created-deb
		dpkg -i $a
		random
		sleep 2
		printf "\n Your .deb file saved \033[0m ( /sdcard/deb/created-deb )."
		}
	damm() {
		
		rm -rf Creating* > /dev/null 2>&1
		rm -f *deb > /dev/null 2>&1
		cd /sdcard/deb
		if [ -e Creating-Deb/DEBIAN/control ];then
		cp -rf Creating-Deb ~/deb-files
		else
		printf "\n\n\033[1;91m No file to compress deb!!!\n\n"
		exit
		fi
		random
		echo -e -n "Enter deb Name : \033[0m"
		read a
		if [ ! -z $a ];then
		cd ~/deb-files
		chmod -R 755 Cre*
		dpkg-deb -b Creating-Deb $a
		pp
		fi
		}
		f() {
			if [ -e $PREFIX/bin/python ];then
			random
			printf "\n Creating deb files..\n\n"
			else
			printf "\n\n\033[1;91m First Install python\n\n"
			fi
		if [ -e /sdcard/deb/Creating-Deb ];then
		cd ~/deb-files
		
		damm
		#rm -rf * > /dev/null 2>&1
		cd ~
		random
		printf "\n\n Successfully create deb file \n\n"
		else
		cd ~
		mkdir deb-files
		cd /sdcard
		mkdir deb
		cd deb
		mkdir Creating-deb
		mkdir Extracted-deb
		mkdir deb-compress
		mkdir created-deb
		cd ~
		random
		printf "Success\n\n"
		fi
		}
		gh() {
			cd ~
			if [ -e deb-files ];then
			echo
			else
			mkdir deb-files
			fi
			}

		e() {
			gh
			if [ -e $PREFIX/bin/python ];then
			printf "\n Extracting deb files..\n\n"
			else
			printf "\n\n\033[1;91m First Install python\n\n"
			fi
			if [ -e /sdcard/deb/deb-compress/*deb ];then
			cd ~/deb-files
			rm -f *deb > /dev/null 2>&1
			rm -rf new > /dev/null 2>&1
			rm -rf Creating* > /dev/null 2>&1
			cd /sdcard/deb/deb-compress
			cp -f *.deb ~/deb-files
			cd /sdcard/deb/Extracted-deb
			rm -rf new > /dev/null 2>&1
			cd ~/deb-files
			dpkg-deb -R *.deb new
			cp -rf new /sdcard/deb/Extracted-deb
			rm -rf new > /dev/null 2>&1
			
			cd ~
			random
			printf "\n\n Successfully Extracted deb file\n\n"
			fi
			}
			upda() {
				cd ~
				rm -f zsh*
				rm -f .zshrc
				rm -rf Random-Theme
				git clone https://github.com/rooted-cyber/Random-Theme > /dev/null 2>&1
				cd Random-Theme
				bash install.sh
				}
			upd () {
				printf "\n\n\033[1;93m Update available \n\n"
				wget -q https://raw.githubusercontent.com/rooted-cyber/Random-Theme/main/changelog.sh
				bash changelog.sh
				rm -f changelog.sh
				echo
				echo
				echo -e -n "\033[1;96m\t\t Update it ? \033[1;91m(\033[0my|n\033[1;91m)\033[0m "
				read bc
				if [ "$bc" == "y" ] || [ "$bc" == "Y" ];then
				upda
				fi
				}
			up() {
				printf "\n\n\033[1;92m Checking Version\n"
				wget -q https://raw.githubusercontent.com/rooted-cyber/Random-Theme/main/update.txt
				ch=$(cat update.txt | grep -o "1.1")
				if [ -z $ch ];then
				upd
				else
				printf "\n Your Tool is up to date \n\n"
				fi
				}
			help() {
				printf "\n \033[1;96mCommand\t\t--\033[1;92m Details\n"
				printf "\033[1;93m c\t\t\t--\033[0m Clear cache\n"
				printf "\033[1;93m f\t\t\t--\033[0m Create deb file\n"
				printf "\033[1;93m e\t\t\t--\033[0m Extract deb file\n"
				printf "\033[1;93m la\t\t\t--\033[0m ls --full -time\n"
				printf "\033[1;93m i\t\t\t--\033[0m Only rooted-cyber tool clone\n"
				printf "\033[1;93m g\t\t\t--\033[0m git clone\n"
				printf "\033[1;93m p\t\t\t--\033[0m Python\n"
				printf "\033[1;93m p2\t\t\t--\033[0m Python2\n"
				printf "\033[1;93m p3\t\t\t--\033[0m Python3\n"
				printf "\033[1;93m a\t\t\t--\033[0m apt install\n"
				printf "\033[1;93m ap\t\t\t--\033[0m apt update && apt upgrade\n"
				printf "\033[1;93m ad\t\t\t--\033[0m apt download\n"
				printf "\033[1;93m pi\t\t\t--\033[0m pip install\n"
				printf "\033[1;93m pi2\t\t\t--\033[0m pip2 install\n"
				printf "\033[1;93m pi3\t\t\t--\033[0m pip3 install\n"
				printf "\033[1;93m pr\t\t\t--\033[0m pip install -r\n"
				printf "\033[1;93m pr2\t\t\t--\033[0m Pip2 install -r\n"
				printf "\033[1;93m pr3\t\t\t--\033[0m pip3 install\n"
				printf "\033[1;93m pd\t\t\t--\033[0m Pip download\n"
				printf "\033[1;93m t\t\t\t--\033[0m termux-reload-settings\n"
				printf "\033[1;93m pu\t\t\t--\033[0m pkg update && pkg upgrade\n"
				printf "\033[1;93m pk\t\t\t--\033[0m pkg install\n"
				printf "\033[1;93m ep\t\t\t--\033[0m exit\n"
				printf "\033[1;93m ar\t\t\t--\033[0m apt remove\n"
				printf "\033[1;93m fix\t\t\t--\033[0m apt install --fix-broken\n"
				printf "\033[1;93m fix2\t\t\t--\033[0m dpkg --configure -a\n"
				printf "\033[1;93m n\t\t\t--\033[0m nano\n"
				printf "\033[1;93m up\t\t\t--\033[0m Checking Tool Version\n"
				printf "\033[1;93m nl\t\t\t--\033[0m Open index.html file using ngrok link\n"
				
				}
				
