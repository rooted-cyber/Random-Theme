import random
import os
color=['\033[1;91m','\033[1;92m','\033[1;93m','\033[1;94m','\033[1;95m','\033[1;96m']
print(random.choice(color))
exit()