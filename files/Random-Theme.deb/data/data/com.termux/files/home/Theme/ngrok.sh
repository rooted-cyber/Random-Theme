checking() {
		if [ -e $PREFIX/bin/curl ];then
		echo
		else
		printf "\n\033[1;93m Installing curl\n"
		apt --fix-broken install
		apt download curl
		dpkg -i curl*
		fi
		if [ -e $PREFIX/bin/php ];then
		echo
		else
		printf "\n\033[1;93m Installing php\n"
		
		apt --fix-broken install
		apt download php
		dpkg -i php*
		fi
		if [ -e $PREFIX/bin/ngrok ];then
		echo
		else
		cd ~
		printf "\n\033[1;93m Downloading Ngrok\n"
		
		wget -q https://github.com/rooted-cyber/Ngrok-All-Version/raw/main/ngrok-2.2.9-linux-arm64.zip
		
		unzip ngrok*
		cp ngrok $PREFIX/bin
		chmod 700 $PREFIX/bin/ngrok
		fi
		}
	killl() {
		pkill -2 ngrok > /dev/null 2>&1
		killall -2 ngrok > /dev/nill 2>&1
		killall -2 php > /dev/null 2>&1
		}
		folc() {
			cd ~
			if [ -e Opening ];then
			echo
			else
			mkdir Opening
			fi
			}
	ci() {
		if [ -e ~/Opening/index.html ];then
		toilet -f font -F metal NGROK
		printf "\n\n\033[1;93m[\033[0m*\033[1;93m]\033[1;92m Startng php server....\n"
		cd ~/Opening
		php -S 127.0.0.1:4444 > /dev/null 2>&1 &
		sleep 3
		printf "\n\n\033[1;93m[\033[0m*\033[1;93m]\033[1;92m Starting Ngrok Server....\n\n"
		cd ~/Opening
		ngrok http 4444 > /dev/null 2>&1 &
		sleep 12
		link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
		printf "\e[1;93m[\e[0m*\e[1;93m]\033[1;92m Your \033[0m Ngrok\033[1;92m link:\e[0m\e[1;77m %s\e[0m\n\n" $link
		else
		printf "\n\n\033[1;91m[×]Not any file found !!!\n\n\033[1;92m[+]\033[1;93m Copy index.html in \033[1;91m(\033[0m~/Opening\033[1;91m)\n\n"
		fi
		}
	nlink() {
		checking
		folc
		cd ~/Opening
		killl
		clear
		ci
		}
		nlink