cd $PREFIX/bin
./toilet -f font -F metal Maruf