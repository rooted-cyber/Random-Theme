c() {
	cd /sdcard/Android > /dev/null 2>&1
	rm -rf data  > /dev/null 2>&1
	cd /sdcard/dcim
	rm -rf .thum*
	cd ~
	}
	pp() {
		cp -f $a ~
		cp -f $a /sdcard/deb/created-deb
		dpkg -i $a
		random
		sleep 2
		printf "\n Your .deb file saved \033[0m ( /sdcard/deb/created-deb )."
		}
	damm() {
		
		rm -rf Creating* > /dev/null 2>&1
		rm -f *deb
		cd /sdcard/deb
		if [ -e Creating-Deb/DEBIAN/control ];then
		cp -rf Creating-Deb ~/deb-files
		else
		printf "\n\n\033[1;91m No file to compress deb!!!\n\n"
		exit
		fi
		random
		echo -e -n "Enter deb Name : \033[0m"
		read a
		if [ ! -z $a ];then
		cd ~/deb-files
		chmod -R 755 Cre*
		dpkg-deb -b Creating-Deb $a
		pp
		fi
		}
		f() {
		if [ -e /sdcard/deb/Creating-Deb ];then
		cd ~/deb-files
		
		damm
		#rm -rf * > /dev/null 2>&1
		cd ~
		random
		printf "\n\n Successfully create deb file \n\n"
		else
		cd ~
		mkdir deb-files
		cd /sdcard
		mkdir deb
		cd deb
		mkdir Creating-deb
		mkdir Extracted-deb
		mkdir deb-compress
		mkdir created-deb
		cd ~
		random
		printf "Success\n\n"
		fi
		}
		e() {
			if [ -e /sdcard/deb/deb-compress/*deb ];then
			cd /sdcard/deb/deb-compress
			cp -f *.deb ~/deb-files
			cd ~/deb-files
			dpkg-deb -R *.deb new
			cp -rf new /sdcard/deb/Extracted-deb
			rm -rf *
			cd ~
			random
			printf "\n\n Successfully Extracted deb file\n\n"
			fi
			}
			help() {
				printf "\n \033[1;96mCommand\t\t--\033[1;92m Details\n"
				printf "\033[1;93m c\t\t\t--\033[0m Clear cache\n"
				printf "\033[1;93m f\t\t\t--\033[0m Create deb file\n"
				printf "\033[1;93m e\t\t\t--\033[0m Extract deb file\n"
				printf "\033[1;93m i\t\t\t--\033[0m Only rooted-cyber tool clone\n"
				printf "\033[1;93m p\t\t\t--\033[0m Python\n"
				printf "\033[1;93m p2\t\t\t--\033[0m Python2\n"
				printf "\033[1;93m p3\t\t\t--\033[0m Python3\n"
				printf "\033[1;93m a\t\t\t--\033[0m apt install\n"
				printf "\033[1;93m ap\t\t\t--\033[0m apt update && apt upgrade\n"
				printf "\033[1;93m ad\t\t\t--\033[0m apt download\n"
				}
				