alias a='apt install'
alias p='python'
alias p2='python2'
alias ad='apt download'
alias p3='python3'
alias g='git clone'
alias ap='apt update && apt upgrade'
alias pi='pip install'
alias pi2='pip2 install'
alias pi3='pip3 install'
alias pr='pip install -r'
alias pr2='pip2 install -r'
alias pr3='pip3 install -r'
alias pd='pip download'
alias pd2='pip2 download'
alias pd3='pip3 download'
alias t='termux-reload-settings'
alias ep='exit'
alias pk='pkg install'
alias pu='pkg update && pkg upgrade'
alias fix='apt install --fix-broken'
alias ar='apt remove'
alias fix2='dpkg --configure -a'
alias n='nano'
alias arr='apt autoremove'
alias af='apt show'

hii() {
	cd ~
if [ -e start ];then
ls > /dev/null 2>&1
else
echo "hi" >> start
fi
}
hii
i() {
echo -e -n "\033[1;92m Enter tool name : \033[0m"
read a
if [ $a ];then
git clone https://github.com/rooted-cyber/$a
fi
}
source ~/Theme/menu.sh

cd ~
nc() {
	if [ -e ~/Theme/name.sh ];then
	rm -f ~/Theme/name.sh
	fi
	}
c-name() {
	nc
	random
	echo
	echo -e -n "Enter your name : \033[0m"
	read a
	if [ $a ];then
	touch ~/Theme/name.sh
	echo "echo '	Happy new year 2021 🎉🎈🎈🎈🎈'|lolcat" >> ~/Theme/name.sh
	echo "echo" >> ~/Theme/name.sh
	echo "toilet -f font -F metal $a" >> ~/Theme/name.sh
	echo "echo '	Happy new year 2021 🎉🎈🎈🎈🎈'|lolcat" >> ~/Theme/name.sh
	fi
	}
