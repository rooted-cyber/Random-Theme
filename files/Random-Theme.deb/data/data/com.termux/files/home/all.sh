clear
source ~/Theme/name.sh
PROMPT=$'
%{\033[1;92m%}╭─%{\033[1;93m%}[%{\033[1;96m%}%~%{\033[1;93m%}]%{\033[1;92m%}─%{\033[1;93m%}[%{\033[1;96m%}%c%{\033[1;93m%}]%{\033[1;92m%}─%{\033[1;93m%}[%{\033[1;96m%}%!%{\033[1;93m%}]%{\033[1;92m%}─%{\033[1;93m%}[%{\033[1;96m%}%@%{\033[1;93m%} ]%{\033[1;92m%}
╰─➤%{\033[3 q%} '
source ~/Theme/b.sh
export ZSH=$HOME/.oh-my-zsh
source $ZSH/oh-my-zsh.sh
source ~/Theme/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
source ~/Theme/zsh-autosuggestions/zsh-autosuggestions.zsh
printf "\n\033[1;93m=========================================================\n"
printf "     \033[0mhttps://github.com/rooted-cyber/Random-Theme"
printf "\n\033[1;93m=========================================================\n"
source ~/Theme/checking.sh
source ~/Theme/changing.sh