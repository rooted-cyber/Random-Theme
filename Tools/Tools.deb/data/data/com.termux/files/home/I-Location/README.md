# Seeker

## Telegram Group : https://t.me/rootedcyber1

## Re-Open Whatsapp Group : https://chat.whatsapp.com/JH8SqlhcIeX0IeC1t2RWmu


<img src="https://github.com/rooted-cyber/I-Location/raw/master/image/I-Location.png" style="width:300px;height:400px;">
<img src="https://github.com/rooted-cyber/I-Location/raw/master/image/I-Location2.png" style="width:300px;height:400px;">
<img src="https://github.com/rooted-cyber/I-Location/raw/master/image/I-Location3.png" style="width:300px;height:400px;">

<pre>
 $ apt update
 $ apt upgrade
 $ apt-get install git
 $ git clone https://github.com/rooted-cyber/I-Location
 $ cd I-Location
 $ bash location.sh
 </pre>
 
 <pre>
 start command :- location</pre>
