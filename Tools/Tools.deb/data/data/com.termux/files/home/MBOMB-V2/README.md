# MBOMB-V2
# installation in termux

<pre> $ apt update
 $ apt upgrade
 $ apt install git
 $ git clone https://github.com/rooted-cyber/MBOMB-V2
 $ cd MBOMB-V2
 $ bash MBOMB.sh </pre>

# usages
Type anywhere
<pre>M</pre>
